from project.task import Task

class Section:

    def __init__(self,name: str):
        self.name=name
        self.tasks=[]
    
    def add_task(self, new_task: Task):
        if new_task not in self.tasks:
            self.tasks.append(new_task)
            return f'Task {new_task.details()} is added to the section'
        return f'Task is already in the section {self.name}'
    
    def complete_task(self, task_name: str):
        for task in self.tasks:
            if task.name==task_name:
                task.completed=True
                return f'Completed task {task.name}'
        return f'Could not find task with the name {task_name}'
    
    def clean_section(self):
        current_tasks=len(self.tasks)
        for task in self.tasks:
            if task.completed:
                idx=self.tasks.index(task)
                self.tasks.pop(idx)
        return f'Cleared {current_tasks-len(self.tasks)} tasks.'
    
    def view_section(self):
        details='\n'.join(task.details() for task in self.tasks)
        return f'Section {self.name}:\n{details}'




            
